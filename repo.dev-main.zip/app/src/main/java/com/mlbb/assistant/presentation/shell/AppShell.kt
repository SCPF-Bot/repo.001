package com.mlbb.assistant.presentation.shell

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Leaderboard
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mlbb.assistant.data.local.preferences.WizardPreference
import com.mlbb.assistant.presentation.common.components.ConnectivityBanner
import com.mlbb.assistant.presentation.common.theme.MLBBGold
import com.mlbb.assistant.presentation.common.theme.SurfaceDark
import com.mlbb.assistant.presentation.common.theme.SurfaceMid
import com.mlbb.assistant.presentation.common.theme.TextSecondary
import com.mlbb.assistant.presentation.navigation.AppNavGraph
import com.mlbb.assistant.presentation.navigation.AppRoute
import com.mlbb.assistant.presentation.navigation.TOP_LEVEL_ROUTES

data class BottomNavItem(
    val route: String,
    val icon: ImageVector,
    val label: String
)

private val NAV_ITEMS = listOf(
    BottomNavItem(AppRoute.Home.route,      Icons.Rounded.Home,        "Home"),
    BottomNavItem(AppRoute.HeroList.route,  Icons.Rounded.Person,      "Heroes"),
    BottomNavItem(AppRoute.MetaBoard.route, Icons.Rounded.Leaderboard, "Meta"),
    BottomNavItem(AppRoute.History.route,   Icons.Rounded.History,     "History"),
    BottomNavItem(AppRoute.Settings.route,  Icons.Rounded.Settings,    "Settings"),
)

/**
 * Root shell composable that owns bottom navigation and routes to [AppNavGraph].
 *
 * The onboarding wizard flag is read from [WizardPreference] (DataStore) via
 * [produceState] so the Composable is lifecycle-aware and avoids reading
 * SharedPreferences synchronously on the composition thread.
 *
 * [ConnectivityBanner] is driven by [AppShellViewModel] which wraps
 * [com.mlbb.assistant.utils.NetworkMonitor] in a lifecycle-safe [StateFlow].
 * The banner slides in/out at the very top of the scaffold content area so
 * it is always visible regardless of which screen is active.
 */
@Composable
fun AppShell(
    onStartOverlay: () -> Unit,
    onRequestCapture: () -> Unit,
    viewModel: AppShellViewModel = hiltViewModel()
) {
    val context = LocalContext.current

    val wizardDone by produceState(initialValue = true, context) {
        WizardPreference.observe(context).collect { done ->
            value = done
        }
    }

    val isOffline by viewModel.isOffline.collectAsStateWithLifecycle()

    val navController: NavHostController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute   = backStackEntry?.destination?.route
    val showBottomBar  = currentRoute in TOP_LEVEL_ROUTES

    Scaffold(
        bottomBar = {
            AnimatedVisibility(
                visible = showBottomBar,
                enter   = slideInVertically { it },
                exit    = slideOutVertically { it }
            ) {
                NavigationBar(
                    containerColor = SurfaceMid,
                    tonalElevation = 0.dp
                ) {
                    NAV_ITEMS.forEach { item ->
                        val selected = currentRoute == item.route
                        NavigationBarItem(
                            selected = selected,
                            onClick  = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState    = true
                                }
                            },
                            icon  = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor   = SurfaceDark,
                                unselectedIconColor = TextSecondary,
                                selectedTextColor   = MLBBGold,
                                unselectedTextColor = TextSecondary,
                                indicatorColor      = MLBBGold
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            ConnectivityBanner(isOffline = isOffline)
            AppNavGraph(
                navController    = navController,
                startAtWizard    = !wizardDone,
                onStartOverlay   = onStartOverlay,
                onRequestCapture = onRequestCapture,
                modifier         = Modifier.fillMaxSize()
            )
        }
    }
}
