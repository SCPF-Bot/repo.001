package com.mlbb.assistant.presentation.main

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import com.mlbb.assistant.presentation.common.theme.MLBBAssistantTheme
import com.mlbb.assistant.presentation.overlay.OverlayService
import com.mlbb.assistant.presentation.shell.AppShell
import com.mlbb.assistant.service.VoiceAlertService
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var voiceAlertService: VoiceAlertService

    /**
     * Launched after the user grants the screen-capture permission dialog.
     * We pass the result directly to OverlayService so it can set up
     * MediaProjection and start the autonomous capture loop — without
     * keeping a local ScreenCaptureManager here.
     *
     * P0-03 fix: replaced `result.data!!` with a safe early-return pattern.
     * The manual `!= null` guard was correct but used `!!` anyway, which
     * bypasses Kotlin's smart-cast and will crash if `data` is somehow null
     * (e.g. under aggressive R8 class rewriting in release builds, or if the
     * activity-result contract changes). Using `?: return@registerForActivityResult`
     * is both safer and idiomatic.
     */
    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode != RESULT_OK) return@registerForActivityResult
        val data = result.data ?: return@registerForActivityResult
        OverlayService.startWithProjection(this, result.resultCode, data)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MLBBAssistantTheme {
                AppShell(
                    onStartOverlay   = { startOverlay() },
                    onRequestCapture = { requestScreenCapture() }
                )
            }
        }
    }

    override fun onDestroy() {
        voiceAlertService.shutdown()
        super.onDestroy()
    }

    /**
     * Called when the user taps "Start Draft".
     *
     * Steps:
     * 1. Verify overlay permission — if missing, open the system settings page
     *    so the user can grant it, instead of silently starting a service that
     *    will just stop itself (previous behavior: [OverlayService] guards its
     *    own `onStartCommand()`/`onCreate()` on `canDrawOverlays()` and calls
     *    `stopSelf()` when the permission is absent, so calling `start()`
     *    without permission was a no-op with no feedback to the user).
     * 2. Start OverlayService immediately (bubble appears).
     * 3. Request screen-capture permission so autonomous detection can start.
     *    The result flows back through [projectionLauncher] → OverlayService.
     */
    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        OverlayService.start(this)
        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
